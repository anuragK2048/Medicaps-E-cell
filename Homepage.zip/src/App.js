import "./App.css";
import Homepage from "./pages/Homepage/Homepage";
import Navbar from "./components/Navbar/Navbar";

function App() {
  return (
    // <div className="App">
    <div>
      <Navbar />
      <Homepage />
    </div>
    // </div>
  );
}

export default App;
